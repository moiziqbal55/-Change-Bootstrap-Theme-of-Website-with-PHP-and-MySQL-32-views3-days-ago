<?php 
	$dbc = mysqli_connect('localhost','root','','moixxweb');
 ?>